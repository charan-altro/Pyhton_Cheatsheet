#!/usr/bin/env python3

"""Solution to chapter 9, exercise 38, beyond 1: beverage"""


class Beverage:
    def __init__(self, name, temp):
        self.name = name
        self.temp = temp
