from e36_freedonia import calculate_tax

print(calculate_tax(100, 'Harpo', 15))
print(calculate_tax(100, 'Harpo', 18))
print(calculate_tax(100, 'Groucho', 20))
print(calculate_tax(100, 'Groucho', 22))
print(calculate_tax(100, 'Chico', 8))
print(calculate_tax(100, 'Chico', 20))
